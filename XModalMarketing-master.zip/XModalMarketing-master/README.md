# XModalMarketing

In this repository there are sound and product image files used in the experiment presented in: 

Peters Rit, Croijmans & Speed (accepted). High-tempo and stinky: High arousing sound-odor congruence affects product memory

These sound files were downloaded from freesound.org licensed under creative commons. A total of 30 sounds were pretested, and the 8 scoring highest and 8 scoring lowest on arousal were selected to be used in the experiment. These can be downloaded here: 

Product images were found using Google images, and scaled to the appropriate dimension (336 pixels wide). The images are available to download here: 


